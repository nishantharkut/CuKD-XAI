import ast
from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "cukd_xai_colab.py"


class FinalRouteStaticTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source_text = SOURCE.read_text(encoding="utf-8")
        cls.tree = ast.parse(cls.source_text)
        cls.function_names = {
            node.name for node in ast.walk(cls.tree) if isinstance(node, ast.FunctionDef)
        }

    def test_final_route_entrypoints_exist(self):
        required = {
            "run_wsnds_final_with_resume",
            "run_dynamic_int8_eval",
            "select_best_kd_seed_from_results",
            "load_student_state_for_profile",
            "run_edgeiiot_qat_and_profile_entrypoint",
            "compute_shap_alignment",
            "run_wsnds_rf_kd_shap_alignment_entrypoint",
            "run_edgeiiot_shap_alignment_entrypoint",
            "write_final_summary_tables",
        }
        self.assertTrue(required.issubset(self.function_names), required - self.function_names)

    def test_qat_and_deployment_guards_are_executable(self):
        self.assertIn("final_mode_enabled('qat_profile'", self.source_text)
        self.assertIn("RUN_QAT_FOR_BEST_STUDENTS or RUN_DEPLOYMENT_PROFILE", self.source_text)
        self.assertIn("run_qat=RUN_QAT_FOR_BEST_STUDENTS or FINAL_RUN_MODE == 'qat_profile'", self.source_text)
        self.assertIn("run_profile=RUN_DEPLOYMENT_PROFILE or FINAL_RUN_MODE == 'qat_profile'", self.source_text)
        self.assertIn("final_mode_enabled('shap_alignment'", self.source_text)
        self.assertIn("RUN_SHAP_ALIGNMENT_FINAL", self.source_text)

    def test_wsnds_resume_function_uses_checkpoint_helpers(self):
        fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "run_wsnds_final_with_resume"
        )
        calls = {
            node.func.id for node in ast.walk(fn)
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name)
        }
        self.assertIn("seed_done", calls)
        self.assertIn("save_seed_metrics", calls)
        self.assertIn("aggregate_seed_metrics", calls)

    def test_quality_helpers_and_no_fixed_tmp_model_path(self):
        self.assertIn("select_quantized_backend", self.function_names)
        self.assertIn("safe_torch_load_state_dict", self.function_names)
        self.assertNotIn("/tmp/_tmp_model.pt", self.source_text)

    def test_wsnds_resume_defaults_to_publication_ten_seeds(self):
        fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "run_wsnds_final_with_resume"
        )
        fn_source = ast.get_source_segment(self.source_text, fn)
        self.assertIn("SEEDS_PUBLICATION10", fn_source)
        self.assertNotIn("seeds or SEEDS)", fn_source)

    def test_legacy_v23_execution_is_guarded_by_default(self):
        self.assertIn("RUN_LEGACY_V23_EXPERIMENTS = False", self.source_text)
        self.assertIn("Skipping legacy v2.3 multi-seed run", self.source_text)
        self.assertIn("if RUN_LEGACY_V23_EXPERIMENTS:", self.source_text)
        self.assertIn("if RUN_LEGACY_V23_EXPERIMENTS and all_seed_results_A:", self.source_text)
        self.assertIn("if RUN_LEGACY_V23_EXPERIMENTS and final_models:", self.source_text)

    def test_deployment_profile_does_not_call_gpu_benchmark_helper(self):
        fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "profile_student_for_deployment"
        )
        fn_source = ast.get_source_segment(self.source_text, fn)
        self.assertIn("measure_cpu_latency_distribution", fn_source)
        self.assertNotIn("measure_inference_time_ms", fn_source)

    def test_final_routes_tune_kd_before_publication_runs(self):
        required = {
            "run_wsnds_kd_grid_search_final",
            "run_rf_kd_grid_search_arrays",
            "resolve_edgeiiot_kd_hyperparams",
        }
        self.assertTrue(required.issubset(self.function_names), required - self.function_names)
        wsnds_fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "run_wsnds_final_with_resume"
        )
        wsnds_source = ast.get_source_segment(self.source_text, wsnds_fn)
        self.assertIn("run_wsnds_kd_grid_search_final", wsnds_source)
        edge_fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "run_edgeiiot_ml_entrypoint"
        )
        edge_source = ast.get_source_segment(self.source_text, edge_fn)
        self.assertIn("resolve_edgeiiot_kd_hyperparams", edge_source)
        self.assertNotIn("kd_T=2.0", edge_source)
        self.assertNotIn("kd_alpha=0.5", edge_source)

    def test_resume_uses_run_config_to_avoid_stale_seed_mixing(self):
        self.assertIn("metrics_match_run_config", self.function_names)
        self.assertIn("attach_run_config", self.function_names)
        self.assertIn("_run_config", self.source_text)
        compact_fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "run_multiseed_compact_with_resume"
        )
        compact_source = ast.get_source_segment(self.source_text, compact_fn)
        self.assertIn("metrics_match_run_config", compact_source)
        self.assertIn("attach_run_config", compact_source)
        wsnds_fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "run_wsnds_final_with_resume"
        )
        wsnds_source = ast.get_source_segment(self.source_text, wsnds_fn)
        self.assertIn("metrics_match_run_config", wsnds_source)
        self.assertIn("attach_run_config", wsnds_source)

    def test_run_all_final_mode_selector_exists(self):
        self.assertIn("FINAL_RUN_MODE = 'none'", self.source_text)
        self.assertIn("validate_final_run_mode", self.function_names)
        self.assertIn("final_mode_enabled", self.function_names)
        selector_fn = next(
            node for node in ast.walk(self.tree)
            if isinstance(node, ast.FunctionDef) and node.name == "final_mode_enabled"
        )
        selector_source = ast.get_source_segment(self.source_text, selector_fn)
        self.assertIn("if mode != 'none':", selector_source)
        self.assertIn("return mode == mode_name", selector_source)
        self.assertIn("return bool(legacy_flag)", selector_source)
        self.assertIn("final_mode_enabled('edge_smoke'", self.source_text)
        self.assertIn("final_mode_enabled('edge_final'", self.source_text)
        self.assertIn("final_mode_enabled('wsnds_final'", self.source_text)
        self.assertIn("final_mode_enabled('qat_profile'", self.source_text)
        self.assertIn("final_mode_enabled('shap_alignment'", self.source_text)


if __name__ == "__main__":
    unittest.main()
